# Loads automapper and associated packages
library("automapper")
library("tmap")

# Shapefiles & Test Data
# Note: File paths may need to be updated depending on where data is stored.
syria_shapefiles <- "data/spatial/Syria/Administrative Boundaries, Populated Places/syr_admin_shp_utf8_180131"
syria_test_data <- "data/prices/Syria/smeb_towns_nb.csv"

# Syria (admin4)
df_key <- "q_town"
spatial_key <- "PCODE"
spatial_layer <- syr_pplp_adm4

##########################################

# Load Shapefiles
load_shape_files(folder_path = syria_shapefiles)

#Load Data
df <- read.csv(syria_test_data, sep = ",",
               fileEncoding = "UTF-8",
               stringsAsFactors = FALSE)


## Join data to Shape File Layer
spatial_layer <- join_df_to_spatial(dataframe = df,
                                    dataframe_key = df_key,
                                    spatial_layer = spatial_layer,
                                    spatial_layer_key = spatial_key)
