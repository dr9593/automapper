###############################################################
### Libya Mapping Example (Whole Country, Iterated by Item) ###
###############################################################

# DEFINE NEEDED INPUTS HERE
output_folder_path <- paste("Output/Libya/Overview Maps")
label_variable <- "community_en"

# Below this Line should not need to touch #
############################################

# Define output directory
dir.create(output_folder_path, recursive = TRUE)

# Set list of variables to map (all but key in original dataframe)
var_list <- names(df)[names(df) != df_key]

#Define Libya Background Map (Whole Country)
background_map_libya_country <-function(){
  admin1_layer <- tm_shape(shp = Lby_Adm1_Geodivision, is.master = TRUE) + tm_borders(lwd = 2)
  admin2_layer <- tm_shape(shp = Lby_Adm2_Mantika) + tm_borders(lwd = .5)
  admin3_layer <- tm_shape(shp = Lby_Adm3_Baladiya) + tm_dots(size = .02)
  admin4_layer <- tm_shape(shp = Lby_Adm4_Muhalla) + tm_dots(size = .01)
  admin1_layer + admin2_layer + admin3_layer + admin4_layer
}

#Create Libya Backgroun Map (Whole Country)
background_map <- background_map_libya_country()

#######################################
# Create Output Map, Iterate per item #
#######################################
lapply(var_list, function(i){

  # fill_map_country creates a country-level map, data displayed as points.
  data_layer <- try(points_map_country(spatial_dataframe = spatial_layer,
                                       # Selects which variable to map
                                       mapping_variable = i,
                                       # Selects variable that you want labeled on the data_layer
                                       label_variable = label_variable))

  # Layer data_layer on top of background
  output_map <- try(background_map + data_layer)

  # Save Map to output file, at specified dimensions
  try(save_tmap(tm = output_map,
                #File name
                filename = paste(output_folder_path,"/",i,"_country_overview_labeled.jpg",
                                 sep = ""),
                # Specify dimensions of image here
                width = 1720, height = 1020, units = "px"))
})

