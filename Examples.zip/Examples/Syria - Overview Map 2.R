###############################################################
### Syria Mapping Example (Whole Country, Iterated by Item) ###
###############################################################

# DEFINE NEEDED INPUTS HERE
output_folder_path <- paste("Output/Syria/Overview Maps")
label_variable <- "NAME_EN"

# Below this Line should not need to touch #
############################################

# Define output directory
dir.create(output_folder_path, recursive = TRUE)

# Set list of variables to map (all but key in original dataframe)
var_list <- names(df)[names(df) != df_key]

# Define Syria Background Map
background_map_syria_country <- function(){
  admin1 <- tm_shape(shp = syr_admin1, is.master = TRUE) + tm_borders(lwd = 2)
  admin3 <- tm_shape(shp = syr_admin3) + tm_borders(lwd = .5)
  admin4 <- tm_shape(shp = syr_pplp_adm4) + tm_dots(size = .01)
  background_map <- admin1 + admin3 + admin4
  background_map
}

#Create Syria Backgroun Map (Whole Country)
background_map <- background_map_syria_country()

#######################################
# Create Output Map, Iterate per item #
#######################################
lapply(var_list, function(i){

  # fill_map_country creates a country-level map, data displayed as points.
  data_layer <- try(points_map_country(spatial_dataframe = spatial_layer,
                                       # Selects which variable to map
                                       mapping_variable = i))

  # Layer data_layer on top of background
  output_map <- try(background_map + data_layer)

  # Save Map to output file, at specified dimensions
  try(save_tmap(tm = output_map,
                # File name
                filename = paste(output_folder_path,"/",i,"_country_overview.jpg",
                                 sep = ""),
                # Specify dimensions of image here
                width = 1720, height = 1020, units = "px"))
})
