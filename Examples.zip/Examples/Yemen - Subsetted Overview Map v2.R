###################################################
###Yemen Mapping Example (Subsetted Background) ###
###################################################

# DEFINE NEEDED INPUTS HERE
output_folder_path <- paste("Output/Yemen/Overview Maps/Subset")
label_variable <- "name_en"
region_subset <- "adm1_en"
background_layer_filter <- "name_en"


# Below this Line should not need to touch #
############################################

# Define output directory
dir.create(output_folder_path, recursive = TRUE)

# Set list of variables to map (all but key in original dataframe)
var_list <- names(df)[names(df) != df_key]

# Subset Regions with Data
region_subset_list <- list_spdf_regions_with_data(spatial_dataframe = spatial_layer,
                                               source_dataframe = df,
                                               df_key = df_key,
                                               spatial_key = spatial_key,
                                               region_to_subset_by = region_subset)

# Define Background Map
background_map_yemen_subset <-function(subset_column_name,subset_value_list){
  admin1_layer <- tm_shape(shp = yem_admin1[yem_admin1[[subset_column_name]] %in% subset_value_list, ], is.master = TRUE) + tm_borders(lwd = 2)
  admin1_layer
}

# Create Background Map (Subsetted)
background_map <- background_map_yemen_subset(subset_column_name = background_layer_filter,
                                              subset_value_list = region_subset_list)

#######################################
# Create Output Map, Iterate per item #
#######################################

####################
# OPTION A: Labels #
####################
lapply(var_list, function(i){

  # fill_map_country creates a country-level map, data displayed as polygons not points.
  data_layer <- try(fill_map_country(spatial_dataframe = spatial_layer,
                                     # Selects which variable to map
                                     mapping_variable = i,
                                     # Selects variable that you want labeled on the data_layer
                                     label_variable = label_variable))

  # Layer data_layer on top of background
  output_map <- try(background_map + data_layer)

  # Save Map to output file, at specified dimensions
  save_tmap(tm = output_map,
            #File name
            filename = paste(output_folder_path,"/",i,"_overview_map_subset_labeled.jpg",
                             sep = ""),
            # Specify dimensions of image here
            width = 1720, height = 1020, units = "px")
})

#######################
# OPTION B: No Labels #
#######################
lapply(var_list, function(i){

  # fill_map_country creates a country-level map, data displayed as polygons not points.
  data_layer <- try(fill_map_country(spatial_dataframe = spatial_layer,
                                     # Selects which variable to map
                                     mapping_variable = i))

  # Layer data_layer on top of background
  output_map <- try(background_map + data_layer)

  # Save Map to output file, at specified dimensions
  save_tmap(tm = output_map,
            #File name
            filename = paste(output_folder_path,"/",i,"_overview_map_subset.jpg",
                             sep = ""),
            # Specify dimensions of image here
            width = 1720, height = 1020, units = "px")
})
