# Loads automapper and associated packages
library("automapper")
library("tmap")

# Shapefiles & Test Data
# Note: File paths may need to be updated depending on where data is stored.
yemen_shapefiles <- "data/spatial/Yemen"
yemen_test_data <- "data/prices/Yemen/march_names.csv"

#Yemen
df_key <- "district" #Key variable in dataframe to merge to geospatial data
spatial_key <- "name_en" #Key variable in geospatial data to merge with dataframe
spatial_layer <- yem_admin2  #Define geospatial data

##########################################
# Load Shapefiles
load_shape_files(folder_path = yemen_shapefiles)

#Load Data
df <- read.csv(yemen_test_data, sep = ",",
               fileEncoding = "UTF-8",
               stringsAsFactors = FALSE)

## Join data to Shape File Layer
spatial_layer <- join_df_to_spatial(dataframe = df,
                                    dataframe_key = df_key,
                                    spatial_layer = spatial_layer,
                                    spatial_layer_key = spatial_key)
