# Loads automapper and associated packages
library("automapper")
library("tmap")

# Shapefiles & Test Data
# Note: File paths may need to be updated depending on where data is stored.
syria_shapefiles <- "data/spatial/Syria/Administrative Boundaries, Populated Places/syr_admin_shp_utf8_180131"
syria_test_data_sbd <- "data/prices/Syria/sbd_medians.csv"


# Load Shapefiles
load_shape_files(folder_path = syria_shapefiles)

#Load Data
df <- read.csv(syria_test_data_sbd, sep = ",",
               fileEncoding = "UTF-8",
               stringsAsFactors = FALSE)

# Syria (admin3)
df_key <- "q_sbd"
spatial_key <- "PCODE"
spatial_layer <- syr_admin3

## Join data to Shape File Layer
spatial_layer <- join_df_to_spatial(dataframe = df,
                                    dataframe_key = df_key,
                                    spatial_layer = spatial_layer,
                                    spatial_layer_key = spatial_key)
